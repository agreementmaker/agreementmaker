package am.matcher.IterativeInstanceStructuralMatcher;

public class AlignIndexes {
	int x;
	int y;
	
	public AlignIndexes(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
}
