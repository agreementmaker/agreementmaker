package am.matcher.LexicalMatcherJAWS;

public class ConceptGroup {

}
