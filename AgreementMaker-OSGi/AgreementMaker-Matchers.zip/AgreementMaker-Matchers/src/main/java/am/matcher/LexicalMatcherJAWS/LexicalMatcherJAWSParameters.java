package am.matcher.LexicalMatcherJAWS;

import am.app.mappingEngine.DefaultMatcherParameters;

public class LexicalMatcherJAWSParameters extends DefaultMatcherParameters {

}
