package am.matcher.ssc;

import am.app.mappingEngine.DefaultMatcherParameters;

public class SiblingsSimilarityContributionParameters extends DefaultMatcherParameters {

	public double MCP = 0.75d;
	
}
