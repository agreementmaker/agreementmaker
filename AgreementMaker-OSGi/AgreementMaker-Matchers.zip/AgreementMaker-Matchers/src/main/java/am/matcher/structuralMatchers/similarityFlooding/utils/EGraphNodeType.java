package am.matcher.structuralMatchers.similarityFlooding.utils;

public enum EGraphNodeType {
	EDGES, VERTEXES
}
