/**
 * 
 */
package am.matcher.structuralMatchers;

import am.app.mappingEngine.abstractMatcherNew.AbstractMatchingParameters;

/**
 * @author michele
 *
 */
public class SimilarityFloodingParameters extends AbstractMatchingParameters {

}
