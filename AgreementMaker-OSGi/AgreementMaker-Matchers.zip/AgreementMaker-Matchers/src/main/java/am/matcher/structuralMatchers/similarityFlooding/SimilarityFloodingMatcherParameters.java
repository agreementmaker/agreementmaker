package am.matcher.structuralMatchers.similarityFlooding;

import am.app.mappingEngine.DefaultMatcherParameters;

public class SimilarityFloodingMatcherParameters extends DefaultMatcherParameters {

	public boolean omitAnonymousNodes = false;
	
}
