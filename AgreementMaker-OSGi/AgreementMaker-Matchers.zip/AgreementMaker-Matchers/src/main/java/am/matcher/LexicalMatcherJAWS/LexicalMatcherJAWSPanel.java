package am.matcher.LexicalMatcherJAWS;

import am.app.mappingEngine.AbstractMatcherParametersPanel;
import am.app.mappingEngine.DefaultMatcherParameters;

public class LexicalMatcherJAWSPanel extends AbstractMatcherParametersPanel {

	private static final long serialVersionUID = 4327476467588851563L;

	@Override
	public DefaultMatcherParameters getParameters() {
		return null;
	}

}
